document.addEventListener('DOMContentLoaded', function() {

    const fabButton = document.getElementById('fabButton');
    const fabMenu = document.getElementById('fabMenu');

    if (fabButton && fabMenu) {
        fabButton.addEventListener('click', function(e) {
            e.stopPropagation();
            fabButton.classList.toggle('active');
            fabMenu.classList.toggle('active');
        });

        document.addEventListener('click', function(e) {
            if (!fabButton.contains(e.target) && !fabMenu.contains(e.target)) {
                fabButton.classList.remove('active');
                fabMenu.classList.remove('active');
            }
        });
    }

    const navLinks = document.querySelectorAll('.nav-link, .nav-link-secondary, .estiloMenu');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const isSecondary = this.classList.contains('nav-link-secondary') || this.classList.contains('estiloMenu');
            const selector = isSecondary ? '.nav-link-secondary, .estiloMenu' : '.nav-link';
            document.querySelectorAll(selector).forEach(l => l.classList.remove('active'));

            this.classList.add('active');

            createRipple(e, this);
        });
    });

    function createRipple(event, element) {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;

        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            left: ${x}px;
            top: ${y}px;
            pointer-events: none;
            animation: rippleEffect 0.6s ease-out;
        `;

        element.style.position = 'relative';
        element.style.overflow = 'hidden';
        element.appendChild(ripple);

        setTimeout(() => ripple.remove(), 600);
    }

    const style = document.createElement('style');
    style.textContent = `
        @keyframes rippleEffect {
            from {
                transform: scale(0);
                opacity: 1;
            }
            to {
                transform: scale(2);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

    const btnSaibaMais = document.querySelector('.btn-saiba-mais');
    if (btnSaibaMais) {
        btnSaibaMais.addEventListener('click', function() {
            alert('Bem-vindo ao AuraMarcada! Sistema completo de agendamento de consultas terapêuticas.');
        });
    }

    const tableRows = document.querySelectorAll('.consultas-table tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.01)';
            this.style.transition = 'transform 0.2s ease';
        });

        row.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });

    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.hero-content, .hero-image, .consultas-container');

        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight;

            if (elementPosition < screenPosition) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    };

    const initAnimations = () => {
        const elements = document.querySelectorAll('.hero-content, .hero-image, .consultas-container');
        elements.forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });

        setTimeout(animateOnScroll, 100);
    };

    initAnimations();
    window.addEventListener('scroll', animateOnScroll);

    console.log('AuraMarcada - Sistema carregado com sucesso! 🌟');
});