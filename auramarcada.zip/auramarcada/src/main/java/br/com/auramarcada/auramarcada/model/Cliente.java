package br.com.auramarcada.auramarcada.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
public class Cliente implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID_Cliente")
    private long ID_Cliente;

    @NotEmpty(message = "O nome é obrigatório")
    private String Nome;

    @NotNull(message = "A data de nascimento é obrigatória")
    private Date DataNascimento;

    @NotEmpty(message = "O telefone é obrigatório")
    private String Telefone;

    @NotEmpty(message = "O sexo é obrigatório")
    private String Sexo;

    @NotNull(message = "A data do último contato é obrigatória")
    private Date UltimoContato;

    @Column(unique = true)
    @NotEmpty(message = "O email é obrigatório")
    @Email(message = "Email inválido")
    private String Email;

    @OneToMany(mappedBy = "cliente", cascade = CascadeType.REMOVE)
    private List<Agendamento> agendamento;


    public long getID_Cliente() {
        return ID_Cliente;
    }

    public void setID_Cliente(long ID_Cliente) {
        this.ID_Cliente = ID_Cliente;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public Date getDataNascimento() {
        return DataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        DataNascimento = dataNascimento;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String sexo) {
        Sexo = sexo;
    }

    public Date getUltimoContato() {
        return UltimoContato;
    }

    public void setUltimoContato(Date ultimoContato) {
        UltimoContato = ultimoContato;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public List<Agendamento> getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(List<Agendamento> agendamento) {
        this.agendamento = agendamento;
    }
}