package br.com.auramarcada.auramarcada.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.auramarcada.auramarcada.repository.AgendamentoRepository;
import br.com.auramarcada.auramarcada.repository.ClienteRepository;
import br.com.auramarcada.auramarcada.repository.TerapeutaRepository;
import br.com.auramarcada.auramarcada.model.Agendamento;
import br.com.auramarcada.auramarcada.model.Cliente;
import br.com.auramarcada.auramarcada.model.Terapeuta;

@Controller
public class AgendamentoController {

    @Autowired
    private AgendamentoRepository ar;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private TerapeutaRepository terapeutaRepository;

    @RequestMapping(value = "/Menu", method = RequestMethod.GET)
    public ModelAndView index() {
        ModelAndView mv = new ModelAndView("auramarcada/index");
        mv.addObject("agendamento", new Agendamento());
        mv.addObject("agendamentos", ar.findAll());
        return mv;
    }

    @RequestMapping(value = "/agendamento", method = RequestMethod.GET)
    public ModelAndView Agendamento() {
        ModelAndView mv = new ModelAndView("auramarcada/agendamento");
        mv.addObject("agendamento", new Agendamento());
        mv.addObject("agendamentos", ar.findAll());
        return mv;
    }

    @RequestMapping(value = "/cadastrarAgendamento", method = RequestMethod.GET)
    public ModelAndView form() {
        ModelAndView mv = new ModelAndView("auramarcada/formAgendamento");
        mv.addObject("agendamento", new Agendamento());
        mv.addObject("clientes", clienteRepository.findAll());
        mv.addObject("terapeutas", terapeutaRepository.findAll());
        return mv;
    }

    @RequestMapping(value = "/cadastrarAgendamento", method = RequestMethod.POST)
    public String salvar(@ModelAttribute Agendamento agendamento,
                         @RequestParam("clienteId") Long clienteId,
                         @RequestParam("terapeutaId") Long terapeutaId,
                         RedirectAttributes attributes) {

        try {
            Cliente cliente = clienteRepository.findById(clienteId)
                    .orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado"));

            Terapeuta terapeuta = terapeutaRepository.findById(terapeutaId)
                    .orElseThrow(() -> new IllegalArgumentException("Terapeuta não encontrado"));

            agendamento.setCliente(cliente);
            agendamento.setTerapeuta(terapeuta);

            ar.save(agendamento);
            attributes.addFlashAttribute("mensagem", "Agendamento cadastrado com Sucesso!");

        } catch (Exception e) {
            attributes.addFlashAttribute("mensagem", "Erro ao cadastrar: " + e.getMessage());
        }

        return "redirect:/listarAgendamento";
    }

    @GetMapping("/listarAgendamento")
    public ModelAndView listarAgendamento() {
        ModelAndView mv = new ModelAndView("auramarcada/listaAgendamento");
        mv.addObject("agendamentos", ar.findAll());
        return mv;
    }

    @GetMapping("/agendamento/{ID_Agendamento}/editar")
    public ModelAndView editarAgendamento(@PathVariable("ID_Agendamento") long ID_Agendamento) {
        Agendamento agendamento = ar.findById(ID_Agendamento).orElseThrow(() -> new IllegalArgumentException("Agendamento não encontrado."));
        ModelAndView mv = new ModelAndView("auramarcada/formAgendamento");
        mv.addObject("agendamento", agendamento);
        mv.addObject("clientes", clienteRepository.findAll());
        mv.addObject("terapeutas", terapeutaRepository.findAll());
        return mv;
    }

    @PostMapping("/agendamento/{ID_Agendamento}/deletar")
    public String deletarAgendamento(@PathVariable("ID_Agendamento") long ID_Agendamento, RedirectAttributes attributes) {
        ar.deleteById(ID_Agendamento);
        attributes.addFlashAttribute("mensagem", "Agendamento removido com Sucesso!");
        return "redirect:/listarAgendamento";
    }
}