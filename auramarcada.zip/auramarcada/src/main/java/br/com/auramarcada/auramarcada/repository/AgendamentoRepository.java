package br.com.auramarcada.auramarcada.repository;

import br.com.auramarcada.auramarcada.model.Agendamento;
import br.com.auramarcada.auramarcada.model.Cliente;
import br.com.auramarcada.auramarcada.model.Terapeuta;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgendamentoRepository extends CrudRepository<Agendamento, Long> {

}