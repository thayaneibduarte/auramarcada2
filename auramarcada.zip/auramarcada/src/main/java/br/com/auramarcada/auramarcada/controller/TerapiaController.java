package br.com.auramarcada.auramarcada.controller;

import br.com.auramarcada.auramarcada.model.Terapia;
import br.com.auramarcada.auramarcada.repository.TerapiaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class TerapiaController {
    @Autowired
    private TerapiaRepository ter;

    @RequestMapping(value = "/terapia", method = RequestMethod.GET)
    public ModelAndView Terapia() {
        ModelAndView mv = new ModelAndView("auramarcada/terapia");
        mv.addObject("terapia", new Terapia());
        mv.addObject("terapias", ter.findAll());
        return mv;
    }

    @RequestMapping(value = "/cadastrarTerapia", method = RequestMethod.GET)
    public ModelAndView form() {
        ModelAndView mv = new ModelAndView("auramarcada/formTerapia");
        mv.addObject("terapia", new Terapia()); //Inicializando objeto para o formulário
        return mv;
    }

    @RequestMapping(value = "/cadastrarTerapia", method = RequestMethod.POST)
    public String salvar(@Valid Terapia terapia, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            attributes.addFlashAttribute("mensagem", "Verifique os campos...");
            return "redirect:/cadastrarTerapia";
        }
        ter.save(terapia);
        attributes.addFlashAttribute("mensagem", "Terapia cadastrada com Sucesso!");
        return "redirect:/listarTerapia";
    }

    @GetMapping("/listarTerapia")
    public ModelAndView listarTerapia() {
        ModelAndView mv = new ModelAndView("auramarcada/listaTerapia");
        mv.addObject("terapias", ter.findAll());
        return mv;
    }

    @GetMapping("/terapia/{ID_Terapia}/editar")
    public ModelAndView editarTerapia(@PathVariable("ID_Terapia") long ID_Terapia) {
        Terapia terapia = ter.findById(ID_Terapia).orElseThrow(() -> new IllegalArgumentException("Terapia não encontrada"));
        ModelAndView mv = new ModelAndView("auramarcada/formTerapia");
        mv.addObject("terapia", terapia);
        return mv;
    }

    @PostMapping("/terapia/{ID_Terapia}/deletar")
    public String deletarTerapia(@PathVariable("ID_Terapia") long ID_Terapia, RedirectAttributes attributes) {
        ter.deleteById(ID_Terapia);
        attributes.addFlashAttribute("mensagem", "Terapia removida com Sucesso!");
        return "redirect:/listarTerapia";

    }
}
