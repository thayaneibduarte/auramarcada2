package br.com.auramarcada.auramarcada.model;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalTime;
import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
public class Agendamento implements Serializable {

    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID_Agendamento")
    private long ID_Agendamento;

    @NotNull(message = "O horário do agendamento é obrigatório")
    private LocalTime Horario_Agendamento;

    @NotNull(message = "A data do agendamento é obrigatória")
    private Date Data_Agendamento;

    @NotEmpty(message = "A queixa inicial é obrigatória")
    private String Queixa_Inicial;

    @ManyToOne
    @JoinColumn(name = "fk_cliente_ID_cliente")
    @NotNull(message = "O cliente é obrigatório")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "fk_terapeuta_id_Terapeuta")
    @NotNull(message = "O terapeuta é obrigatório")
    private Terapeuta terapeuta;

    @OneToMany(mappedBy = "agendamento", cascade = CascadeType.REMOVE)
    private List<Consulta> consulta;


    public long getID_Agendamento() {
        return ID_Agendamento;
    }

    public void setID_Agendamento(long ID_Agendamento) {
        this.ID_Agendamento = ID_Agendamento;
    }

    public LocalTime getHorario_Agendamento() {
        return Horario_Agendamento;
    }

    public void setHorario_Agendamento(LocalTime horario_Agendamento) {
        Horario_Agendamento = horario_Agendamento;
    }

    public Date getData_Agendamento() {
        return Data_Agendamento;
    }

    public void setData_Agendamento(Date data_Agendamento) {
        Data_Agendamento = data_Agendamento;
    }

    public String getQueixa_Inicial() {
        return Queixa_Inicial;
    }

    public void setQueixa_Inicial(String queixa_Inicial) {
        Queixa_Inicial = queixa_Inicial;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Terapeuta getTerapeuta() {
        return terapeuta;
    }

    public void setTerapeuta(Terapeuta terapeuta) {
        this.terapeuta = terapeuta;
    }

    public List<Consulta> getConsulta() {
        return consulta;
    }

    public void setConsulta(List<Consulta> consulta) {
        this.consulta = consulta;
    }
}