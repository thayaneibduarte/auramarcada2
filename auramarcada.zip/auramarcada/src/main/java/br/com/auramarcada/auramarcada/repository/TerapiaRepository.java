package br.com.auramarcada.auramarcada.repository;

import br.com.auramarcada.auramarcada.model.Terapia;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TerapiaRepository extends CrudRepository<Terapia, Long> {

}
