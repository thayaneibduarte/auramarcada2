package br.com.auramarcada.auramarcada.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.io.Serializable;
import java.util.List;

@Entity
public class Terapia implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID_Terapia")
    private long ID_Terapia;

    @NotEmpty(message = "O nome é obrigatório")
    @Size(max = 255, message = "O nome deve ter no máximo 255 caracteres")
    private String Nome;

    @NotEmpty(message = "A duração é obrigatória")
    @Size(max = 255, message = "A duração deve ter no máximo 255 caracteres")
    private String Duracao;

    @NotEmpty(message = "A descrição é obrigatória")
    @Size(max = 255, message = "A descrição deve ter no máximo 255 caracteres")
    private String Descricao;

    @OneToMany(mappedBy = "terapia", cascade = CascadeType.REMOVE)
    private List<Consulta> consulta;

    public long getID_Terapia() {
        return ID_Terapia;
    }

    public void setID_Terapia(long ID_Terapia) {
        this.ID_Terapia = ID_Terapia;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getDuracao() {
        return Duracao;
    }

    public void setDuracao(String duracao) {
        Duracao = duracao;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    public List<Consulta> getConsulta() {
        return consulta;
    }

    public void setConsulta(List<Consulta> consulta) {
        this.consulta = consulta;
    }
}