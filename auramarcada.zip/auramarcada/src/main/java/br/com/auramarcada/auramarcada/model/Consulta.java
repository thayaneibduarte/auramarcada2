package br.com.auramarcada.auramarcada.model;

import java.io.Serializable;
import java.sql.Date;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
public class Consulta implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID_Consulta")
    private long ID_Consulta;

    @NotNull(message = "A data de realização é obrigatória")
    private Date DataRealizacao;

    @NotEmpty(message = "O tratamento é obrigatório")
    private String Tratamento;

    @NotEmpty(message = "A modalidade é obrigatória")
    private String Modalidade;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_Agendamento_ID_Agendamento")
    @NotNull(message = "O agendamento é obrigatório")
    private Agendamento agendamento;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_Terapias_ID_Terapias")
    @NotNull(message = "A terapia é obrigatória")
    private Terapia terapia;


    public long getID_Consulta() {
        return ID_Consulta;
    }

    public void setID_Consulta(long ID_Consulta) {
        this.ID_Consulta = ID_Consulta;
    }

    public Date getDataRealizacao() {
        return DataRealizacao;
    }

    public void setDataRealizacao(Date dataRealizacao) {
        DataRealizacao = dataRealizacao;
    }

    public String getTratamento() {
        return Tratamento;
    }

    public void setTratamento(String tratamento) {
        Tratamento = tratamento;
    }

    public String getModalidade() {
        return Modalidade;
    }

    public void setModalidade(String modalidade) {
        Modalidade = modalidade;
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public Terapia getTerapia() {
        return terapia;
    }

    public void setTerapia(Terapia terapia) {
        this.terapia = terapia;
    }
}