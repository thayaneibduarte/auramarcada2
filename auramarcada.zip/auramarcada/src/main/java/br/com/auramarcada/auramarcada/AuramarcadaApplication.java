package br.com.auramarcada.auramarcada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuramarcadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuramarcadaApplication.class, args);
	}

}
