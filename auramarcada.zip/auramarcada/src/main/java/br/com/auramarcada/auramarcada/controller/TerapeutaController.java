package br.com.auramarcada.auramarcada.controller;

import br.com.auramarcada.auramarcada.model.Terapeuta;
import br.com.auramarcada.auramarcada.repository.TerapeutaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class TerapeutaController {

    @Autowired
    private TerapeutaRepository tr;

    @RequestMapping(value = "/terapeuta", method = RequestMethod.GET)
    public ModelAndView Terapeuta() {
        ModelAndView mv = new ModelAndView("auramarcada/terapeuta");
        mv.addObject("terapeutas", tr.findAll());
        mv.addObject("terapeuta", new Terapeuta());
        return mv;
    }

    @RequestMapping(value = "/cadastrarTerapeuta", method = RequestMethod.GET)
    public ModelAndView form() {
        ModelAndView mv = new ModelAndView("auramarcada/formTerapeuta");
        mv.addObject("terapeuta", new Terapeuta()); //Inicializando objeto para o formulário
        return mv;
    }

    @RequestMapping(value = "/cadastrarTerapeuta", method = RequestMethod.POST)
    public String salvar(@Valid Terapeuta terapeuta, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            attributes.addFlashAttribute("mensagem", "Verifique os campos...");
            return "redirect:/cadastrarTerapeuta";
        }
        tr.save(terapeuta);
        attributes.addFlashAttribute("mensagem", "Terapeuta cadastrada com Sucesso!");
        return "redirect:/listarTerapeuta";
    }

    @GetMapping("/listarTerapeuta")
    public ModelAndView listarTerapeuta() {
        ModelAndView mv = new ModelAndView("auramarcada/listaTerapeuta");
        mv.addObject("terapeutas", tr.findAll());
        return mv;
    }

    @GetMapping("/terapeuta/{ID_Terapeuta}/editar")
    public ModelAndView editarTerapeuta(@PathVariable("ID_Terapeuta") long ID_Terapeuta) {
       Terapeuta terapeuta = tr.findById(ID_Terapeuta).orElseThrow(() -> new IllegalArgumentException("Terapeuta não encontrado"));
        ModelAndView mv = new ModelAndView("auramarcada/formTerapeuta");
        mv.addObject("terapeuta", terapeuta);
        return mv;
    }

    @PostMapping("/terapeuta/{ID_Terapeuta}/deletar")
    public String deletarTerapeuta(@PathVariable("ID_Terapeuta") long ID_Terapeuta, RedirectAttributes attributes) {
        tr.deleteById(ID_Terapeuta);
        attributes.addFlashAttribute("mensagem", "Terapeuta removido com Sucesso!");
        return "redirect:/listarTerapeuta";

    }
}

