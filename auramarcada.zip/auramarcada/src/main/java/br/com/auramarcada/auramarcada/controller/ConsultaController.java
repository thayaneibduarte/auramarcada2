package br.com.auramarcada.auramarcada.controller;

import br.com.auramarcada.auramarcada.model.Agendamento;
import br.com.auramarcada.auramarcada.model.Consulta;
import br.com.auramarcada.auramarcada.model.Terapia;
import br.com.auramarcada.auramarcada.repository.ConsultaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import br.com.auramarcada.auramarcada.repository.TerapiaRepository;
import br.com.auramarcada.auramarcada.repository.AgendamentoRepository;

@Controller
public class ConsultaController {

    @Autowired
    private ConsultaRepository cor;

    @Autowired
    private TerapiaRepository terapiaRepository;

    @Autowired
    private AgendamentoRepository agendamentoRepository;


    @RequestMapping(value = "/consulta", method = RequestMethod.GET)
    public ModelAndView Consulta() {
        ModelAndView mv = new ModelAndView("auramarcada/consulta");
        mv.addObject("consulta", new Consulta());
        mv.addObject("consultas", cor.findAll());
        return mv;
    }

    @RequestMapping(value = "/cadastrarConsulta", method = RequestMethod.GET)
    public ModelAndView form() {
        ModelAndView mv = new ModelAndView("auramarcada/formConsulta");
        mv.addObject("consulta", new Consulta());
        mv.addObject("consultas", cor.findAll());
        mv.addObject("terapias", terapiaRepository.findAll());
        mv.addObject("agendamentos", agendamentoRepository.findAll());
        return mv;
    }

    @RequestMapping(value = "/cadastrarConsulta", method = RequestMethod.POST)
    public String salvar(@ModelAttribute Consulta consulta,
                         @RequestParam("agendamentoId") Long agendamentoId,
                         @RequestParam("terapiaId") Long terapiaId,
                         RedirectAttributes attributes) {

        try {
            Agendamento agendamento = agendamentoRepository.findById(agendamentoId)
                    .orElseThrow(() -> new IllegalArgumentException("Agendamento não encontrado"));

            Terapia terapia = terapiaRepository.findById(terapiaId)
                    .orElseThrow(() -> new IllegalArgumentException("Terapia não encontrada"));

            consulta.setAgendamento(agendamento);
            consulta.setTerapia(terapia);
            cor.save(consulta);
            attributes.addFlashAttribute("mensagem", "Consulta cadastrada com Sucesso!");

        } catch (Exception e) {
            attributes.addFlashAttribute("mensagem", "Erro ao cadastrar: " + e.getMessage());
        }

        return "redirect:/listarConsulta";
    }

    @GetMapping("/listarConsulta")
    public ModelAndView listarConsulta() {
        ModelAndView mv = new ModelAndView("auramarcada/listaConsulta");
        mv.addObject("consultas", cor.findAll());
        return mv;
    }

    @GetMapping("/consulta/{ID_Consulta}/editar")
    public ModelAndView editarConsulta(@PathVariable("ID_Consulta") long ID_Consulta) {
        Consulta consulta = cor.findById(ID_Consulta).orElseThrow(() -> new IllegalArgumentException("Consulta não encontrada"));
        ModelAndView mv = new ModelAndView("auramarcada/formConsulta");
        mv.addObject("consulta", consulta);
        mv.addObject("terapias", terapiaRepository.findAll());
        mv.addObject("agendamentos", agendamentoRepository.findAll());
        return mv;
    }

    @PostMapping("/consulta/{ID_Consulta}/deletar")
    public String deletarConsulta(@PathVariable("ID_Consulta") long ID_Consulta, RedirectAttributes attributes) {
        cor.deleteById(ID_Consulta);
        attributes.addFlashAttribute("mensagem", "Consulta removida com Sucesso!");
        return "redirect:/listarConsulta";

    }
}
