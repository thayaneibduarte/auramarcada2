package br.com.auramarcada.auramarcada.repository;

import br.com.auramarcada.auramarcada.model.Cliente;
import br.com.auramarcada.auramarcada.model.Consulta;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsultaRepository extends CrudRepository<Consulta, Long> {


}
