package br.com.auramarcada.auramarcada.controller;

import br.com.auramarcada.auramarcada.model.Cliente;
import br.com.auramarcada.auramarcada.repository.ClienteRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ClienteController {

    @Autowired
    private ClienteRepository cr;

    @RequestMapping(value = "/cliente", method = RequestMethod.GET)
    public ModelAndView Cliente() {
        ModelAndView mv = new ModelAndView("auramarcada/cliente");
        mv.addObject("cliente", new Cliente());
        mv.addObject("clientes", cr.findAll());
        return mv;
    }

    @RequestMapping(value = "/cadastrarCliente", method = RequestMethod.GET)
    public ModelAndView form() {
        ModelAndView mv = new ModelAndView("auramarcada/formCliente");
        mv.addObject("cliente", new Cliente());
        return mv;
    }

    @RequestMapping(value = "/cadastrarCliente", method = RequestMethod.POST)
    public String salvar(@Valid Cliente cliente, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            attributes.addFlashAttribute("mensagem", "Verifique os campos...");
            return "redirect:/cadastrarCliente";
        }
        cr.save(cliente);
        attributes.addFlashAttribute("mensagem", "Cliente cadastrado com Sucesso!");
        return "redirect:/listarCliente";
    }

    @GetMapping("/listarCliente")
    public ModelAndView listarCliente() {
        ModelAndView mv = new ModelAndView("auramarcada/listaCliente");
        mv.addObject("clientes", cr.findAll());
        return mv;
    }

    @GetMapping("/cliente/{ID_Cliente}/editar")
    public ModelAndView editarCliente(@PathVariable("ID_Cliente") long ID_Cliente){
       Cliente cliente = cr.findById(ID_Cliente).orElseThrow(() -> new IllegalArgumentException("Cliente não encontrado"));
        ModelAndView mv = new ModelAndView("auramarcada/formCliente");
        mv.addObject("cliente", cliente);
        return mv;
    }

    @PostMapping("/cliente/{ID_Cliente}/deletar")
    public String deletarCliente(@PathVariable("ID_Cliente") long ID_Cliente, RedirectAttributes attributes){
        cr.deleteById(ID_Cliente);
        attributes.addFlashAttribute("mensagem", "Cliente removido com Sucesso!");
        return "redirect:/listarCliente";

    }
}

