package br.com.auramarcada.auramarcada.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

@Entity
public class Terapeuta implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID_Terapeuta")
    private long ID_Terapeuta;

    @NotEmpty(message = "O nome é obrigatório")
    private String Nome;

    @OneToMany(mappedBy = "terapeuta", cascade = CascadeType.REMOVE)
    private List<Agendamento> agendamento;


    public long getID_Terapeuta() {
        return ID_Terapeuta;
    }

    public void setID_Terapeuta(long ID_Terapeuta) {
        this.ID_Terapeuta = ID_Terapeuta;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public List<Agendamento> getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(List<Agendamento> agendamento) {
        this.agendamento = agendamento;
    }
}