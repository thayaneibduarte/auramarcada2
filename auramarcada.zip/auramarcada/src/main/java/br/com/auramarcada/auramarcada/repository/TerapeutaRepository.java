package br.com.auramarcada.auramarcada.repository;

import br.com.auramarcada.auramarcada.model.Terapeuta;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TerapeutaRepository extends CrudRepository<Terapeuta, Long> {

}
